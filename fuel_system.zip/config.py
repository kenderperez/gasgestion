class Config:
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'tu_password'
    MYSQL_DB = 'combustible_db'
    MYSQL_CURSORCLASS = 'DictCursor'

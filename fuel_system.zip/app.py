from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from config import Config
from functools import wraps
import MySQLdb.cursors

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = 'clave_secreta'
mysql = MySQL(app)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'loggedin' not in session:
            flash('Debes iniciar sesión primero')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM usuarios WHERE username=%s AND password=SHA2(%s,256)", (username, password))
        user = cur.fetchone()
        if user:
            session['loggedin'] = True
            session['username'] = user['username']
            flash('Bienvenido, ' + user['username'])
            return redirect(url_for('dashboard'))
        else:
            flash('Usuario o contraseña incorrectos')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Sesión cerrada correctamente')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    cur = mysql.connection.cursor()
    cur.execute("SELECT SUM(litros) as total_litros, SUM(precio) as total_precio FROM registros")
    resumen = cur.fetchone()
    cur.execute("SELECT vehiculo, SUM(litros) as litros FROM registros GROUP BY vehiculo")
    litros_por_vehiculo = cur.fetchall()
    cur.close()
    return render_template('dashboard.html', resumen=resumen, litros_por_vehiculo=litros_por_vehiculo)

@app.route('/')
@login_required
def index():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM registros ORDER BY fecha DESC")
    data = cur.fetchall()
    cur.close()
    return render_template('index.html', registros=data)

@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_registro():
    if request.method == 'POST':
        vehiculo = request.form['vehiculo']
        conductor = request.form['conductor']
        litros = request.form['litros']
        precio = request.form['precio']
        fecha = request.form['fecha']
        cur = mysql.connection.cursor()
        cur.execute("""INSERT INTO registros (vehiculo, conductor, litros, precio, fecha)
                     VALUES (%s, %s, %s, %s, %s)""", (vehiculo, conductor, litros, precio, fecha))
        mysql.connection.commit()
        flash('Registro agregado correctamente')
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<id>', methods=['GET', 'POST'])
@login_required
def edit_registro(id):
    cur = mysql.connection.cursor()
    if request.method == 'POST':
        vehiculo = request.form['vehiculo']
        conductor = request.form['conductor']
        litros = request.form['litros']
        precio = request.form['precio']
        fecha = request.form['fecha']
        cur.execute("""UPDATE registros SET vehiculo=%s, conductor=%s, litros=%s, precio=%s, fecha=%s WHERE id=%s""", 
                    (vehiculo, conductor, litros, precio, fecha, id))
        mysql.connection.commit()
        flash('Registro actualizado correctamente')
        return redirect(url_for('index'))
    cur.execute("SELECT * FROM registros WHERE id=%s", (id,))
    data = cur.fetchone()
    cur.close()
    return render_template('edit.html', registro=data)

@app.route('/delete/<id>', methods=['POST'])
@login_required
def delete_registro(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM registros WHERE id=%s", (id,))
    mysql.connection.commit()
    flash('Registro eliminado correctamente')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
